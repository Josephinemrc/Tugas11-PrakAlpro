file_name = input("Enter a file name: ")

try:
    with open(file_name, 'r') as file_handle:
        hour_counts = dict()

        for line in file_handle:
            if line.startswith('From '):
                time = line.split()[5]
                hour = time.split(':')[0]
                hour_counts[hour] = hour_counts.get(hour, 0) + 1

        for hour in sorted(hour_counts):
            print(hour, hour_counts[hour])

except FileNotFoundError:
    print("File cannot be opened:", file_name)