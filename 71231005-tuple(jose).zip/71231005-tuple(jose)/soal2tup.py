data = ('Matahari Bhakti Nendya', '22064091', 'Bantul, DI Yogyakarta')

nama = data[0]
nim = data[1]
alamat = data[2]

nim_tup = tuple(nim)
nama_depan = nama.split()[0]  
nama_depan_tup = tuple(nama_depan[1:]) 
nama_terbalik_tup = tuple(nama.split()[::-1]) 

print(f"Data: {data}\n")
print(f"NIM : {nim}")
print(f"NAMA : {nama}")
print(f"ALAMAT : {alamat}\n")
print(f"NIM: {nim_tup}\n")
print(f"NAMA DEPAN: {nama_depan_tup}\n")
print(f"NAMA TERBALIK: {nama_terbalik_tup}\n") 


