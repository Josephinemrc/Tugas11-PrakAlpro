def cek(tup):
    return all(elem == tup[0] for elem in tup)
tA = (90, 90, 90, 90)
print(cek(tA))
